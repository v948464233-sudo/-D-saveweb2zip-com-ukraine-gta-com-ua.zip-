<html><head>
<meta charset="utf-8"></head><body>{
    "name": "Redyx GTA",
    "short_name": "Redyx GTA",
    "description": "Це український ролеплей проєкт, створений українськими розробниками на платформі MTA. Гра, в якій є графіка та можливості GTA 5 RP. Це український РП проєкт, створений за мотивами кримінальної України.",
    "icons": [
        { "src": "\/images\/apple-touch-icon.png", "sizes": "180x180", "type": "image/png" },
        { "src": "\/images\/favicon-48x48.png", "sizes": "48x48", "type": "image/png" }
    ],
    "lang": "uk-UA",
    "dir": "LTR",
    "display": "minimal-ui",
    "scope": "\/",
    "start_url": "\/?_pwa=1",
    "background_color": "#121219",
    "theme_color": "#121219"
}</body></html>